﻿using ASUS.MVVM.Model;


namespace ASUS.MVVM.ViewModel
{
    internal class MainViewModel
    {
        public MainMenuSection[] MainMenuSections { get; set; } = null!;
        public Service[] Services { get; set; } = null!;

        public MainViewModel()
        {
            InitMainMenuSections();
            InitServices();
        }

        private void InitMainMenuSections()
        {
            MainMenuSections = new MainMenuSection[5];
            MainMenuSections[0] = new MainMenuSection(id: 1,
                                                           name: "Формирование отчётов",
                                                           description: "Форма для выгрузки информации по совершённым Операциям." +
                                                                        "Операция - это Услуга, которую определённый пользователь" +
                                                                        "совершил по определённому Нормативу за определённое время.");
            MainMenuSections[1] = new MainMenuSection(id: 2,
                                                           name: "Сервисы",
                                                           description: "Верхний уровень деления услуг." +
                                                                        "В одном Сервисе может быть несколько Групп услуг." +
                                                                        "В базе данных таблица 'FunctionCategory'.");
            MainMenuSections[2] = new MainMenuSection(id: 3,
                                                           name: "Группы услуг",
                                                           description: "Нижний уровень деления услуг." +
                                                                        "В одной Группе услуг может быть несколько Услуг." +
                                                                        "В базе данных таблица 'FunctionGroup'.");
            MainMenuSections[3] = new MainMenuSection(id: 4,
                                                           name: "Услуги",
                                                           description: "Услуга - это действие, которое может совершить исполнитель." +
                                                                        "Одна Услуга может выполняться в разных системах." +
                                                                        "Одна Услуга может выполняться разными исполнителями." +
                                                                        "По одной Услуге может быть несколько Нормативов." +
                                                                        "В базе данных таблица 'Function'.");
            MainMenuSections[4] = new MainMenuSection(id: 5,
                                                           name: "Нормативы",
                                                           description: "Норматив - условия,");
        }

        private void InitServices()
        {
            Services = new Service[3];
            Services[0] = new Service(code: 1,
                                      name: "Бухгалтерский и налоговый учёт",
                                      description: string.Empty);
            Services[1] = new Service(code: 2,
                                      name: "Сопровождение методологии бухгалтерского учёта",
                                      description: string.Empty);
            Services[2] = new Service(code: 3,
                                      name: "Управление методологией в области налогообложения",
                                      description: string.Empty);
        }
    }
}
