﻿namespace ASUS.MVVM.Model
{
    internal class Service
    {
        public int Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public string DisplayedName { get; set; }

        public Service(int code, string name, string description)
        {
            Code = code;
            Name = name;
            Description = description;

            DisplayedName = string.Join(' ', code.ToString("D2"), Name);
        }
    }
}