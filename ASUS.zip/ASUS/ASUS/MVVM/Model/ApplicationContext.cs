﻿using Microsoft.EntityFrameworkCore;


namespace ASUS.MVVM.Model
{
    internal class ApplicationContext: DbContext
    {
        private static readonly string connString = "";

        public DbSet<Service> Services { get; set; } = null!;

        public ApplicationContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connString);
        }
    }
}
